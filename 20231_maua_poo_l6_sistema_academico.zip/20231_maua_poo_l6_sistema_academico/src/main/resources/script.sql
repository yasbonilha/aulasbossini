-- SELECT * FROM tb_usuario_l6;
-- INSERT INTO tb_usuario_l6
-- (login, senha)
-- VALUES
-- ('admin', 'admin');

-- CREATE TABLE tb_usuario_l6(
-- 	cod_usuario SERIAL PRIMARY KEY,
-- 	login VARCHAR(200),
-- 	senha VARCHAR(200)
-- );



