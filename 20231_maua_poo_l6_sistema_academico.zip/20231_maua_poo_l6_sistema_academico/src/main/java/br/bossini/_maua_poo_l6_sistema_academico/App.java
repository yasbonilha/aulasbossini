/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.bossini._maua_poo_l6_sistema_academico;

/**
 *
 * @author rodrigo
 */
public class App {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
