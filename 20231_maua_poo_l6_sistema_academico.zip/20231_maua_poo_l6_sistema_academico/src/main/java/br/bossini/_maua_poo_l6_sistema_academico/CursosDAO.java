
package br.bossini._maua_poo_l6_sistema_academico;
import java.util.List;
import java.util.ArrayList;

public class CursosDAO {
    //lista de objetos do tipo curso
    public List <Cursos> obterCursos() throws Exception{
        List <Cursos> cursos = new ArrayList<>();
        //operador diamante (para você não ter que escrver a paramétrica duas vezes);
        String sql = "SELECT * FROM tb_curso";
        //try-with-resources
        try(
            var conexao = ConnectionFactory.obterConexao();
            var ps = conexao.prepareStatement(sql);
            var rs = ps.executeQuery();
        ){
            while (rs.next()){
                int codigo = rs.getInt("cod_curso");
                String nome = rs.getString("nome");
                String tipo = rs.getString("tipo");
                //construo o objeto java
                var curso = new Cursos(codigo, nome, tipo);
                //adicionando na lista
                cursos.add(curso);
            }
            
        }
        return cursos;
    }
}
