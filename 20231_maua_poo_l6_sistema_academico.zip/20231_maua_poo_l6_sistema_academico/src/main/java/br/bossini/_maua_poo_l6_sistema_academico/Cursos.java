
package br.bossini._maua_poo_l6_sistema_academico;

public class Cursos {
    //temos que criar uma classe de cursos para criar objetos da classe curso no futuro na nossa tela!
    //não precisamos utilizar o código de bd em java
    //mapeamento objeto relacional!!
    
    private int codigo;
    private String nome;
    private String tipo;
    
    //construtor padrão
    public Cursos() {
    }
    
    //construtor personalizado (com valores a serem atribuídos
    public Cursos(int codigo, String nome, String tipo) {
        this.codigo = codigo;
        this.nome = nome;
        this.tipo = tipo;
    }
    
    

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public String toString(){
        //tem como função estabelecer a conversão do objeto para a representação textual
        //vai aparecer só o nome do curso.
        return nome;
    }
    
}
